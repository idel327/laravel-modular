<?php

namespace Idel\Modular\Tests;

use Orchestra\Testbench\TestCase as OrchestraTestCase;
use Idel\Modular\ServiceProvider;

abstract class TestCase extends OrchestraTestCase
{
    protected function getPackageProviders($app)
    {
        return [
            ServiceProvider::class,
        ];
    }

    protected function getEnvironmentSetUp($app)
    {
        $app['config']->set('laravel-modules.modulesPath', __DIR__ . '/../tests/modules');
    }
}
