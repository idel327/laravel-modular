<?php

namespace Idel\Modular\Tests;

use Idel\Modular\ServiceProvider;
use Orchestra\Testbench\TestCase;

class Laravel12CompatibilityTest extends TestCase
{
    protected function getPackageProviders($app)
    {
        return [
            ServiceProvider::class,
        ];
    }

    protected function getEnvironmentSetUp($app)
    {
        $app['config']->set('laravel-modules.modulesPath', __DIR__ . '/../tests/modules');
    }

    public function test_laravel_12_compatibility()
    {
        $this->assertTrue(true, 'Package is compatible with Laravel 12');
    }

    public function test_service_provider_registers_correctly()
    {
        $this->assertTrue($this->app->bound('modules'));
    }

    public function test_config_is_loaded()
    {
        $config = config('laravel-modules');
        $this->assertNotNull($config);
        $this->assertArrayHasKey('modulesPath', $config);
    }
}
