<?php

namespace Idel\Modular\Tests;

use Idel\Modular\RepositoryManager;
use Idel\Modular\Repositories\LocalRepository;

class ModuleTest extends TestCase
{
    protected $repositoryManager;

    protected function setUp(): void
    {
        parent::setUp();
        $this->repositoryManager = app('modules');
    }

    public function test_can_get_modules_repository()
    {
        $this->assertInstanceOf(RepositoryManager::class, $this->repositoryManager);
    }

    public function test_can_get_local_repository()
    {
        $repository = $this->repositoryManager->location();
        $this->assertInstanceOf(LocalRepository::class, $repository);
    }

    public function test_modules_helper_function()
    {
        $modules = modules();
        $this->assertInstanceOf(RepositoryManager::class, $modules);
    }

    public function test_module_path_helper_function()
    {
        $path = module_path();
        $this->assertStringContainsString('modules', $path);
    }
}
