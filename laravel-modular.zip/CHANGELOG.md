# Changelog

All notable changes to this project will be documented in this file.

## [2.1.0] - 2025-02-XX

### Added
- Laravel 12 compatibility
- Symfony 8.0 support
- Updated test dependencies for Laravel 12

### Changed
- Updated composer.json for Laravel 10|11|12 support
- Updated Symfony packages to support version 8.0
- Updated README badges for Laravel 12

## [2.0.0] - 2024-01-XX

### Added
- Laravel 11 compatibility
- Comprehensive test suite with PHPUnit
- Better error handling in helper functions
- Improved performance with better caching
- Support for PHP 8.2+

### Changed
- Updated composer.json for Laravel 10|11 support
- Improved ServiceProvider with better error handling
- Enhanced RepositoryManager performance
- Better type safety in helper functions
- Improved GeneratorCommand error handling

### Fixed
- Fixed deprecated Laravel patterns
- Fixed potential null pointer exceptions
- Improved collection handling
- Better error messages for missing modules

### Removed
- Removed deprecated `$defer` property from ServiceProvider
- Removed old PHP 8.0 support

## [1.0.0] - 2023-XX-XX

### Added
- Initial release
- Module management system
- Artisan commands for module generation
- Laravel Nova support
- Migration system for modules
