<?php

namespace Idel\Modular;

use Illuminate\Support\ServiceProvider as LaravelServiceProvider;

class ServiceProvider extends LaravelServiceProvider
{
    
    /**
     * Bootstrap the provided services.
     */
    public function boot()
    {
        $this->publishFiles();
        $this->app['modules']->register();
    }

    /**
     * Register the provided services.
     */
    public function register()
    {
        $this->app->register(ConsoleServiceProvider::class);
        $this->app->register(GeneratorServiceProvider::class);

        $this->app->singleton('modules', function ($app) {
            return new RepositoryManager($app);
        });
    }

    /**
     * Publish files.
     */
    public function publishFiles()
    {
        $configPath = __DIR__ . '/../config/laravel-modules.php';

        if (config('laravel-modules') === null) {
            $this->mergeConfigFrom($configPath, 'laravel-modules');
        }

        $this->publishes(
            [
                $configPath => config_path('laravel-modules.php'),
            ],
            'config'
        );
    }

    /**
     * Get the services provided by the package.
     *
     * @return array
     */
    public function provides()
    {
        return ['modules'];
    }
}