# Contributing

Thank you for considering contributing to Laravel Modular!

## Development Setup

1. Fork the repository
2. Clone your fork: `git clone https://github.com/your-username/laravel-modular.git`
3. Install dependencies: `composer install`
4. Run tests: `composer test`

## Pull Request Process

1. Create a feature branch: `git checkout -b feature/amazing-feature`
2. Make your changes
3. Add tests for new functionality
4. Ensure all tests pass: `composer test`
5. Commit your changes: `git commit -m 'Add amazing feature'`
6. Push to your branch: `git push origin feature/amazing-feature`
7. Open a Pull Request

## Coding Standards

- Follow PSR-12 coding standards
- Add PHPDoc comments for all public methods
- Write tests for new functionality
- Update documentation as needed

## Testing

We use PHPUnit for testing. Make sure to:

- Run tests before submitting PR: `composer test`
- Add tests for new features
- Ensure test coverage doesn't decrease

## Laravel Version Support

This package supports:
- Laravel 10.x
- Laravel 11.x  
- Laravel 12.x

When adding new features, ensure compatibility with all supported versions.

## Reporting Issues

When reporting issues, please include:

- Laravel version
- PHP version
- Package version
- Steps to reproduce
- Expected vs actual behavior

## License

By contributing, you agree that your contributions will be licensed under the MIT License.
